package id.sttbandung.gridviewlist;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class DaftarLagu extends AppCompatActivity {
    @Override
    protected void onCreate (Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_daftar_lagu);
        ListView list = (ListView) findViewById(R.id.listView);
        String[] DaftarLagu ={"Peterpan-Mungkin Nanti","Letto-Ruang Rindu","GIGI - 11 Januari", "Sheila On Seven-Sahabat Sejati", "Dewa19-PUPUS", "UNGU-Cinta Dalam Hati", "Nidji-Jangan Lupakan", "Ari Lasso-Hampa" };
        ArrayAdapter<String> myAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,DaftarLagu);
        list.setAdapter(myAdapter);

    }
}
